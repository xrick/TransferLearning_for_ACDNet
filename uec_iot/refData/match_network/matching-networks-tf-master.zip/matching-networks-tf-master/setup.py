import setuptools
from setuptools import setup


setup(name='matchnet',
      version='0.0.1',
      license='MIT',
      packages=setuptools.find_packages(),
      install_requires=['Pillow', 'tqdm'])
