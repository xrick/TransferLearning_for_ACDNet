from .train.train_setup import train
from .eval.eval_setup import eval