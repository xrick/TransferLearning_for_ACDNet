# FindSilence

Voice activity detection tool for files. Can't be used for audio stream in real-time.

type

    ./findsilence.sh --help 

for help.
